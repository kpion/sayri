Mini framework by Konrad Papała.

