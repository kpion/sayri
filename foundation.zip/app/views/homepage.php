<p>Ala ma kota a o jest widok</p>
<p>Test zmiennej:<?=$param1?>