<form method='post'>
	<div>Login:<input type='text' name='login'></div>
	<div>Password:<input type='text' name='password'></div>
	<div><input type='submit' value='Login' name='go'></div>
</form>	
