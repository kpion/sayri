			<footer>
				Stopka w front/footer
			</footer>
		</div><!--end of div class='page'-->
	</body>
</html>