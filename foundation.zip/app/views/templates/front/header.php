<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		
		<link rel="stylesheet" type="text/css" href="<?=Url::base()?>assets/css/common.css">
		<link rel="stylesheet" type="text/css" href="<?=Url::base()?>assets/css/frontend.css">
	</head>
	<header>
		Nagłówek w front/header
	</header>
	<body>
		<div class="page">
