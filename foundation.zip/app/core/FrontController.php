<?php
namespace app\core;
class FrontController extends \app\core\BaseController{
	
}

