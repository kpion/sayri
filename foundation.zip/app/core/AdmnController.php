<?php
namespace app\core;
class AdminController extends BaseController{
	
}
