<?php
$config=[
	'config','db'
];

return $config;