<?php
$config=[
	'default'=>[
		'dsn'=>'mysql:host=localhost;dbname=foundation',
		'user'=>'root',
		'password'=>'',
	],
];

return $config;