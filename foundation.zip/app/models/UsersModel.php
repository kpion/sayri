<?php
namespace app\models;
class UsersModel extends \app\core\model{
	public function login(){
		echo \Input::post('login');
	}
}