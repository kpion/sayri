<?php
class UsersController extends app\core\FrontController{
	public function actionLogin(){
		$musers=new app\models\UsersModel();
		//echo \Config::get('test');
		if(Input::post('go')!=''){
			$musers->login();
		}
		\User::login('user1','user1');
		\User::logout();
		var_dump(\User::cur());
		$allUsers=\App::$db->query('select * from users')->result();
		$test=\App::$db->getWhere('users',array('id'=>1))->resultOne();
		//\App
		//var_dump($test);
		$this->render('users/login',['allUsers'=>$allUsers]);
	}
}