<?php
class HomepageController extends \app\core\FrontController{
	public function actionIndex(){
		echo '<br>index in controller!';
	}
	
	public function actionTest($param1,$param2){
		//echo \Input::post('blah');
		//echo \Config::get('test');
		echo 'baseUrl:'.\Url::base();
		$mhomePage=new app\models\HomepageModel();
		$mhomePage->test();
		//$test=new system\Model();
		$this->render('homepage',['param1'=>$param1,'param2'=>$param2]);
	}
}
?>
