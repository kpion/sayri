<?php
$config=[
	'default'=>[
		'dsn'=>'mysql:host=localhost;dbname=calendar',
		'user'=>'root',
		'password'=>'',
	],
];

return $config;