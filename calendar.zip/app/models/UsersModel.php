<?php
namespace app\models;
class UsersModel extends \app\core\Model{
}