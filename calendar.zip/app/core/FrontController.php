<?php
namespace app\core;
class FrontController extends \app\core\BaseController{
	public function __construct(){
		parent::__construct();
	}
}

