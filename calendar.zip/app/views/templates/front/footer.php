			<footer>
				Zalogowany jako: <?=User::cur()['login']?User::cur()['login']:'niezalogowany';?>
			</footer>
		</div><!--end of div class='page'-->
	</body>
</html>